'use strict';

const AWS = require('aws-sdk');
const stepfunctions = new AWS.StepFunctions();


module.exports.executeStepFunction = (event, context, callback) => {
  console.log('executeStepFunction');
  const number = event.queryStringParameters.number;
  console.log(number);

  callStepFunction(number).then(result => {
    let message = number.toString();
    if (!result) {
      message = ' Step function is no t executing';
    }
    const respose = {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Step function is executing',
        input: event
      })
    };
    callback(null, respose);
  });
};

module.exports.calculateRandomNumber = (event, context, callback) => {
  //return {statusCode: 200, body: "OK Random"};
  console.log('calculate function called');
  callback(null, null);
}

function callStepFunction(number, context, callback) {
  {
    console.log('step function called');
    const stateMachineName = 'testingStateMachine';

    return stepfunctions
      .listStateMachines({})
      .promise()
      .then(listStateMachines => {
        console.log('search for step function listStateMachine', listStateMachines);
        console.log(listStateMachines.stateMachines.length);
        console.log(listStateMachines.stateMachines[0]);

        for (var i = 0; i < listStateMachines.stateMachines.length; i++) {
          const item = listStateMachines.stateMachines[i];
          console.log(item);
          if (item.name.indexOf(stateMachineName) >= 0) {
            console.log('Found the step function', item);
            var params = {
              stateMachineArn: item.stateMachineArn,
              input: JSON.stringify({
                number: number
              })
            };

            console.log('Start execution of step function');
            return stepfunctions.startExecution(params).promise().then(() => {
              return true;
            });
          }

        }
      })
      .catch(error => {
        console.log('Error execution of step function');
        return false;
      })
  }
}